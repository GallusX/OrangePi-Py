from io import open
from setuptools import setup, find_packages

setup(name='opigallus',
      version='0.9.3',
      author='Gallus',
      author_email='bkmz_repvby@mail.ru',
      description='opigallus',
      packages=['opigallus']
      )
