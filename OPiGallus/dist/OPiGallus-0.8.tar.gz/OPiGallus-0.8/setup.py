from io import open
from setuptools import setup, find_packages

setup(name='OPiGallus',
      version='0.8',
      author='Gallus',
      author_email='bkmz_repvby@mail.ru',
      description='OPiGallus',
      packages=['opigallus']
      )
